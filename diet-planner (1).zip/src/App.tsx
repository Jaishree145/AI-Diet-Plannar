import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { UserProfile, DietPlan, WeightLog, EatenLog, UserAccount } from './types';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import ProfileForm from './components/ProfileForm';
import DietPlanView from './components/DietPlanView';
import ProgressTracker from './components/ProgressTracker';
import { 
  Activity, 
  Scale, 
  Carrot, 
  User, 
  LogOut, 
  Flame, 
  Sparkles, 
  ClipboardList, 
  LineChart, 
  ChevronRight,
  Info
} from 'lucide-react';

export default function App() {
  const [username, setUsername] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // Loaded account state
  const [profile, setProfile] = useState<UserProfile | undefined>(undefined);
  const [dietPlan, setDietPlan] = useState<DietPlan | undefined>(undefined);
  const [weightHistory, setWeightHistory] = useState<WeightLog[]>([]);
  const [eatenLogs, setEatenLogs] = useState<EatenLog[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Auto log in if active username session exists
  useEffect(() => {
    const activeSession = localStorage.getItem('diet_planner_active_user');
    if (activeSession) {
      handleLoginSuccess(activeSession);
    }
  }, []);

  // Handle successful login
  const handleLoginSuccess = (user: string) => {
    setUsername(user);
    localStorage.setItem('diet_planner_active_user', user);

    // Load account details
    const storedUsers = JSON.parse(localStorage.getItem('diet_planner_accounts') || '{}');
    const account = storedUsers[user];

    if (account) {
      setProfile(account.profile);
      setDietPlan(account.dietPlan);
      setWeightHistory(account.weightHistory || []);
      setEatenLogs(account.eatenLogs || []);
      
      // Default tab if they have a diet plan, otherwise default to profile configuration
      if (account.profile && account.dietPlan) {
        setActiveTab('dashboard');
      } else {
        setActiveTab('profile');
      }
    }
  };

  // Helper to save current state back to the user account in localStorage
  const saveAccountState = (
    updatedProfile: UserProfile | undefined,
    updatedDietPlan: DietPlan | undefined,
    updatedWeight: WeightLog[],
    updatedEaten: EatenLog[]
  ) => {
    if (!username) return;

    const storedUsers = JSON.parse(localStorage.getItem('diet_planner_accounts') || '{}');
    if (storedUsers[username]) {
      storedUsers[username].profile = updatedProfile;
      storedUsers[username].dietPlan = updatedDietPlan;
      storedUsers[username].weightHistory = updatedWeight;
      storedUsers[username].eatenLogs = updatedEaten;
      localStorage.setItem('diet_planner_accounts', JSON.stringify(storedUsers));
    }
  };

  // Log weight additions
  const handleAddWeightLog = (weightVal: number, dateStr: string) => {
    const newLog: WeightLog = {
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
      date: dateStr,
      weight: weightVal
    };

    const updatedWeight = [...weightHistory, newLog];
    setWeightHistory(updatedWeight);
    saveAccountState(profile, dietPlan, updatedWeight, eatenLogs);
  };

  // Delete weight log
  const handleDeleteWeightLog = (id: string) => {
    const updatedWeight = weightHistory.filter(w => w.id !== id);
    setWeightHistory(updatedWeight);
    saveAccountState(profile, dietPlan, updatedWeight, eatenLogs);
  };

  // Toggle meal eaten/not-eaten status
  const handleToggleMeal = (dateStr: string, mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks') => {
    const existingLogIndex = eatenLogs.findIndex(log => log.date === dateStr);
    let updatedEaten = [...eatenLogs];

    if (existingLogIndex !== -1) {
      const currentLog = eatenLogs[existingLogIndex];
      const currentMealState = currentLog.meals[mealType];
      
      updatedEaten[existingLogIndex] = {
        ...currentLog,
        meals: {
          ...currentLog.meals,
          [mealType]: !currentMealState
        }
      };
    } else {
      // Create new record
      const newLog: EatenLog = {
        date: dateStr,
        meals: {
          breakfast: false,
          lunch: false,
          dinner: false,
          snacks: false,
          [mealType]: true
        }
      };
      updatedEaten.push(newLog);
    }

    setEatenLogs(updatedEaten);
    saveAccountState(profile, dietPlan, weightHistory, updatedEaten);
  };

  // Submit profile to server and generate personalized diet plan
  const handleProfileSubmit = async (newProfile: UserProfile) => {
    setIsLoading(true);
    setError(null);

    try {
      // 1. Compute target calorie on server
      const calcResponse = await fetch('/api/calculate-targets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProfile)
      });

      if (!calcResponse.ok) {
        throw new Error('Failed to compute health targets on server.');
      }

      const calculatedData = await calcResponse.json();
      const targetCalories = calculatedData.targetCalories;

      // 2. Query Gemini API via Express secure proxy to create 7-day diet plan
      const generateResponse = await fetch('/api/generate-diet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile: newProfile,
          targetCalories: targetCalories
        })
      });

      if (!generateResponse.ok) {
        const errorData = await generateResponse.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to generate diet plan using Gemini API.');
      }

      const generatedPlan = await generateResponse.json();
      
      const newDietPlanObj: DietPlan = {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
        createdAt: new Date().toISOString(),
        days: generatedPlan.days
      };

      // Set state & Save to storage
      setProfile(newProfile);
      setDietPlan(newDietPlanObj);
      saveAccountState(newProfile, newDietPlanObj, weightHistory, eatenLogs);
      
      // Navigate to dashboard
      setActiveTab('dashboard');

    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Force regenerate on demand using current profile parameters
  const handleRegeneratePlan = () => {
    if (profile) {
      handleProfileSubmit(profile);
    }
  };

  const handleLogout = () => {
    setUsername(null);
    localStorage.removeItem('diet_planner_active_user');
    setProfile(undefined);
    setDietPlan(undefined);
    setWeightHistory([]);
    setEatenLogs([]);
  };

  // Main UI routing
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            profile={profile}
            dietPlan={dietPlan}
            weightHistory={weightHistory}
            eatenLogs={eatenLogs}
            onNavigate={setActiveTab}
            onToggleMeal={handleToggleMeal}
          />
        );
      case 'diet':
        return dietPlan && profile ? (
          <DietPlanView
            dietPlan={dietPlan}
            profile={profile}
            eatenLogs={eatenLogs}
            onToggleMeal={handleToggleMeal}
            onRegenerate={handleRegeneratePlan}
            isRegenerating={isLoading}
          />
        ) : (
          <div className="bg-white rounded-2xl border p-12 text-center max-w-lg mx-auto shadow-sm">
            <ClipboardList className="h-12 w-12 text-emerald-400 mx-auto" />
            <h3 className="mt-4 text-base font-bold text-gray-900">No Diet Plan Available</h3>
            <p className="mt-2 text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
              Create your medical metrics profile. Our AI will automatically construct a customized 7-day nutritional schedule.
            </p>
            <button
              onClick={() => setActiveTab('profile')}
              className="mt-5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-xs font-bold text-white rounded-xl shadow-sm transition-all cursor-pointer"
            >
              Configure Profile
            </button>
          </div>
        );
      case 'progress':
        return (
          <ProgressTracker
            weightHistory={weightHistory}
            onAddLog={handleAddWeightLog}
            onDeleteLog={handleDeleteWeightLog}
          />
        );
      case 'profile':
        return (
          <ProfileForm
            initialProfile={profile}
            onSubmit={handleProfileSubmit}
            isLoading={isLoading}
          />
        );
      default:
        return null;
    }
  };

  // Return Auth module if not logged in
  if (!username) {
    return <Auth onLoginSuccess={handleLoginSuccess} />;
  }

  // Navigation Items
  const navItems = [
    { key: 'dashboard', label: 'Dashboard', icon: Activity },
    { key: 'diet', label: 'Meal Schedule', icon: Carrot },
    { key: 'progress', label: 'Weight Tracker', icon: Scale },
    { key: 'profile', label: 'Configure Profile', icon: User }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      
      {/* Header Top Navigation */}
      <header className="bg-white border-b border-gray-150 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 bg-emerald-500 rounded-lg flex items-center justify-center text-white font-bold">
                <Activity className="h-5 w-5" />
              </div>
              <span className="text-base font-black tracking-tight text-gray-950 flex items-center gap-1">
                Diet Planner <Sparkles className="h-4 w-4 text-emerald-500 fill-emerald-100 shrink-0" />
              </span>
            </div>

            {/* Desktop Navigation Tabs */}
            <nav className="hidden md:flex gap-1.5 h-full items-center">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => setActiveTab(item.key)}
                    className={`px-3 py-2 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
                      active
                        ? 'bg-emerald-50 text-emerald-700 font-extrabold shadow-sm ring-1 ring-emerald-200/50'
                        : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {item.label}
                  </button>
                );
              })}
            </nav>

            {/* Profile Menu & Logout */}
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <span className="block text-[10px] text-gray-400 font-bold uppercase">Logged in as</span>
                <span className="block text-xs font-bold text-gray-800 font-mono">@{username}</span>
              </div>
              <button
                onClick={handleLogout}
                className="p-2 border border-gray-200 rounded-xl text-gray-400 hover:text-red-500 hover:bg-red-50/50 transition-all cursor-pointer"
                title="Log Out"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Main Content Pane */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* API Error Alert Banner */}
        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 text-red-700 text-xs font-medium max-w-3xl mx-auto"
          >
            <Info className="h-5 w-5 shrink-0 text-red-500" />
            <div className="space-y-1">
              <p className="font-bold">Nutrition Plan Generation Error</p>
              <p className="leading-relaxed text-red-600">{error}</p>
            </div>
          </motion.div>
        )}

        {/* Tab content renderer */}
        <div className="relative">
          {renderTabContent()}
        </div>

      </main>

      {/* Mobile Sticky Footer Navigation */}
      <nav className="md:hidden bg-white border-t border-gray-150 sticky bottom-0 left-0 right-0 z-40 px-4 py-2 flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
                active ? 'text-emerald-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="truncate max-w-[70px]">{item.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </nav>

    </div>
  );
}
