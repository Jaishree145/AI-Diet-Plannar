import { useState } from 'react';
import { motion } from 'motion/react';
import { DietPlan, UserProfile, EatenLog } from '../types';
import { CheckCircle2, Circle, Flame, Sparkles, RefreshCw, ChevronDown, ChevronUp, Check, Scale } from 'lucide-react';

interface DietPlanViewProps {
  dietPlan: DietPlan;
  profile: UserProfile;
  eatenLogs: EatenLog[];
  onToggleMeal: (dateStr: string, mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks') => void;
  onRegenerate: () => void;
  isRegenerating: boolean;
}

const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday'
];

export default function DietPlanView({
  dietPlan,
  profile,
  eatenLogs,
  onToggleMeal,
  onRegenerate,
  isRegenerating
}: DietPlanViewProps) {
  // Get current day of the week to default
  const todayIndex = new Date().getDay();
  const currentDayName = DAYS_OF_WEEK[todayIndex];
  
  // Find matching day index in the diet plan, default to first day if not found
  const initialDayIndex = dietPlan.days.findIndex(
    d => d.dayName.toLowerCase() === currentDayName.toLowerCase()
  );
  
  const [selectedDayIdx, setSelectedDayIdx] = useState(initialDayIndex !== -1 ? initialDayIndex : 0);
  const [expandedMeals, setExpandedMeals] = useState<Record<string, boolean>>({
    breakfast: true,
    lunch: true,
    dinner: true,
    snacks: false
  });

  // Calculate local date string in YYYY-MM-DD
  const getTodayDateStr = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayDateStr = getTodayDateStr();

  // Find or create eaten log for today
  const todayLog = eatenLogs.find(log => log.date === todayDateStr) || {
    date: todayDateStr,
    meals: { breakfast: false, lunch: false, dinner: false, snacks: false }
  };

  const currentDayPlan = dietPlan.days[selectedDayIdx];
  const { meals } = currentDayPlan;

  // Calculate totals for the selected day in plan
  const totalCalories = 
    meals.breakfast.calories + 
    meals.lunch.calories + 
    meals.dinner.calories + 
    meals.snacks.calories;

  const totalProtein = 
    meals.breakfast.protein + 
    meals.lunch.protein + 
    meals.dinner.protein + 
    meals.snacks.protein;

  const totalCarbs = 
    meals.breakfast.carbs + 
    meals.lunch.carbs + 
    meals.dinner.carbs + 
    meals.snacks.carbs;

  const totalFat = 
    meals.breakfast.fat + 
    meals.lunch.fat + 
    meals.dinner.fat + 
    meals.snacks.fat;

  const toggleMealExpanded = (mealType: string) => {
    setExpandedMeals(prev => ({ ...prev, [mealType]: !prev[mealType] }));
  };

  // Helper to check if a specific day is "Today"
  const isSelectedDayToday = currentDayPlan.dayName.toLowerCase() === currentDayName.toLowerCase();

  // Meal types list
  const mealTypes = [
    { key: 'breakfast' as const, label: 'Breakfast', color: 'border-amber-150 bg-amber-50/30' },
    { key: 'lunch' as const, label: 'Lunch', color: 'border-sky-150 bg-sky-50/20' },
    { key: 'dinner' as const, label: 'Dinner', color: 'border-indigo-150 bg-indigo-50/20' },
    { key: 'snacks' as const, label: 'Snacks & Mid-meals', color: 'border-emerald-150 bg-emerald-50/10' }
  ];

  // Adherence calculate
  const eatenCount = Object.values(todayLog.meals).filter(Boolean).length;
  const adherencePercent = Math.round((eatenCount / 4) * 100);

  return (
    <div className="space-y-6 font-sans">
      
      {/* 7-Day Selector Bar */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm overflow-x-auto">
        <div className="flex gap-2 min-w-max pb-1">
          {dietPlan.days.map((day, idx) => {
            const isSelected = idx === selectedDayIdx;
            const isActualToday = day.dayName.toLowerCase() === currentDayName.toLowerCase();
            return (
              <button
                key={day.dayName}
                onClick={() => setSelectedDayIdx(idx)}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 min-w-[85px] transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-500'
                    : 'bg-gray-50/50 text-gray-600 hover:bg-gray-100 border border-gray-100'
                }`}
              >
                <span>{day.dayName}</span>
                {isActualToday && (
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-md ${isSelected ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-600'}`}>
                    Today
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Daily Summary & Macro breakdown */}
        <div className="space-y-6 lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">{currentDayPlan.dayName} Nutrition</h3>
                <span className="text-xs font-bold text-emerald-600 font-mono">Plan Totals</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">Calculated nutrition breakdown for the day.</p>
            </div>

            {/* Calories Gauge */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50/40 border border-emerald-100/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-500 text-white flex items-center justify-center">
                  <Flame className="h-5 w-5 fill-current" />
                </div>
                <div>
                  <span className="block text-[10px] uppercase tracking-wider text-gray-500 font-bold">Planned Calories</span>
                  <span className="block text-2xl font-black font-mono text-gray-900">{totalCalories} <span className="text-xs font-normal text-gray-500">kcal</span></span>
                </div>
              </div>
              <div className="text-right">
                <span className="block text-[9px] text-gray-400 font-bold">Target Cal Calories</span>
                <span className="block text-sm font-bold font-mono text-gray-700">{profile.weight ? Math.round(totalCalories) : '--'} kcal</span>
              </div>
            </div>

            {/* Macro breakdown progress */}
            <div className="space-y-4">
              <span className="block text-xs font-bold text-gray-500 uppercase tracking-wider">Estimated Macronutrients</span>
              
              {/* Protein */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-gray-600">Protein (g)</span>
                  <span className="font-mono text-gray-900 font-bold">{totalProtein}g</span>
                </div>
                <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: `${Math.min(100, (totalProtein / 140) * 100)}%` }} />
                </div>
              </div>

              {/* Carbs */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-gray-600">Carbohydrates (g)</span>
                  <span className="font-mono text-gray-900 font-bold">{totalCarbs}g</span>
                </div>
                <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-sky-500 h-full rounded-full" style={{ width: `${Math.min(100, (totalCarbs / 250) * 100)}%` }} />
                </div>
              </div>

              {/* Fat */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-gray-600">Fat (g)</span>
                  <span className="font-mono text-gray-900 font-bold">{totalFat}g</span>
                </div>
                <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-rose-500 h-full rounded-full" style={{ width: `${Math.min(100, (totalFat / 90) * 100)}%` }} />
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-4 border-t border-gray-50">
              <button
                onClick={onRegenerate}
                disabled={isRegenerating}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-xs font-bold text-gray-700 shadow-sm disabled:bg-gray-50 transition-all cursor-pointer"
              >
                <RefreshCw className={`h-4 w-4 text-emerald-500 ${isRegenerating ? 'animate-spin' : ''}`} />
                {isRegenerating ? 'Regenerating...' : 'Regenerate 7-Day Plan'}
              </button>
            </div>
          </div>

          {/* Today's Adherence Card */}
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-4">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Today's Meal Adherence</h3>
              <p className="text-xs text-gray-400 mt-1">Check meals eaten on today's scheduled diet plan.</p>
            </div>

            <div className="relative pt-2">
              <div className="flex justify-between items-center text-xs font-bold mb-1.5 text-emerald-700">
                <span>Completed today</span>
                <span>{adherencePercent}%</span>
              </div>
              <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${adherencePercent}%` }} 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              {(['breakfast', 'lunch', 'dinner', 'snacks'] as const).map((mealKey) => {
                const eaten = todayLog.meals[mealKey];
                return (
                  <button
                    key={mealKey}
                    onClick={() => onToggleMeal(todayDateStr, mealKey)}
                    className={`p-2 rounded-xl border flex items-center gap-2 transition-all text-left cursor-pointer ${
                      eaten 
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                        : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50/50'
                    }`}
                  >
                    {eaten ? (
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
                    ) : (
                      <Circle className="h-4 w-4 shrink-0 text-gray-300" />
                    )}
                    <span className="capitalize font-medium truncate">{mealKey}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right column: Diet Plan list for selected day */}
        <div className="space-y-4 lg:col-span-2">
          
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-gray-100">
            <h3 className="text-sm font-bold text-gray-900">Scheduled Meals ({currentDayPlan.dayName})</h3>
            <span className="text-[10px] text-gray-400">Tap meal title to collapse/expand recipe details</span>
          </div>

          {mealTypes.map((mealType) => {
            const meal = meals[mealType.key];
            const isExpanded = expandedMeals[mealType.key];
            
            // Is this meal marked as eaten today (only applicable if selectedDay is indeed today's plan day)
            const isMealEaten = isSelectedDayToday && todayLog.meals[mealType.key];

            return (
              <motion.div
                key={mealType.key}
                layout
                className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
              >
                {/* Meal header */}
                <div 
                  className="p-4 sm:p-5 flex items-center justify-between gap-3 cursor-pointer select-none"
                  onClick={() => toggleMealExpanded(mealType.key)}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Meal Mark Eaten (interactive ONLY if selectedDay is Today) */}
                    {isSelectedDayToday ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleMeal(todayDateStr, mealType.key);
                        }}
                        className={`h-7 w-7 rounded-lg border flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                          isMealEaten
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'bg-white border-gray-200 text-gray-400 hover:border-emerald-500 hover:bg-emerald-50/50'
                        }`}
                      >
                        <Check className={`h-4 w-4 font-bold transition-all ${isMealEaten ? 'scale-100' : 'scale-0'}`} />
                      </button>
                    ) : (
                      <div className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                    )}

                    <div className="min-w-0">
                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-600 block">
                        {mealType.label}
                      </span>
                      <h4 className={`text-base font-bold text-gray-900 mt-0.5 truncate ${isMealEaten ? 'line-through text-gray-400' : ''}`}>
                        {meal.mealName}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <span className="block text-sm font-black font-mono text-gray-900">{meal.calories} <span className="text-[10px] font-normal text-gray-500">kcal</span></span>
                    </div>
                    <div>
                      {isExpanded ? <ChevronUp className="h-5 w-5 text-gray-400" /> : <ChevronDown className="h-5 w-5 text-gray-400" />}
                    </div>
                  </div>
                </div>

                {/* Meal details (expanded) */}
                {isExpanded && (
                  <div className={`px-4 sm:px-6 pb-5 border-t border-gray-50 ${mealType.color} space-y-4`}>
                    
                    {/* Macros */}
                    <div className="grid grid-cols-3 gap-2 pt-4">
                      <div className="bg-white/80 p-2 rounded-xl border border-gray-100 text-center">
                        <span className="block text-[10px] font-bold text-gray-400 uppercase">Protein</span>
                        <span className="block text-sm font-extrabold font-mono text-amber-600">{meal.protein}g</span>
                      </div>
                      <div className="bg-white/80 p-2 rounded-xl border border-gray-100 text-center">
                        <span className="block text-[10px] font-bold text-gray-400 uppercase">Carbs</span>
                        <span className="block text-sm font-extrabold font-mono text-sky-600">{meal.carbs}g</span>
                      </div>
                      <div className="bg-white/80 p-2 rounded-xl border border-gray-100 text-center">
                        <span className="block text-[10px] font-bold text-gray-400 uppercase">Fat</span>
                        <span className="block text-sm font-extrabold font-mono text-rose-600">{meal.fat}g</span>
                      </div>
                    </div>

                    {/* Ingredients */}
                    <div className="space-y-1.5">
                      <span className="block text-xs font-bold text-gray-500 uppercase tracking-wider">Ingredients & Quantities</span>
                      <ul className="space-y-1.5 bg-white/70 p-3.5 rounded-xl border border-gray-100">
                        {meal.ingredients.map((ing, i) => (
                          <li key={i} className="text-xs text-gray-700 flex items-start gap-2 leading-relaxed">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                            <span>{ing}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                  </div>
                )}

              </motion.div>
            );
          })}

        </div>

      </div>

    </div>
  );
}
