import { motion } from 'motion/react';
import { UserProfile, DietPlan, WeightLog, EatenLog } from '../types';
import { Scale, Activity, Flame, ChevronRight, CheckCircle2, Circle, TrendingDown, Sparkles } from 'lucide-react';

interface DashboardProps {
  profile?: UserProfile;
  dietPlan?: DietPlan;
  weightHistory: WeightLog[];
  eatenLogs: EatenLog[];
  onNavigate: (tab: string) => void;
  onToggleMeal: (dateStr: string, mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks') => void;
}

const DAYS_OF_WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function Dashboard({
  profile,
  dietPlan,
  weightHistory,
  eatenLogs,
  onNavigate,
  onToggleMeal
}: DashboardProps) {
  // Compute date string
  const getTodayDateStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const todayDateStr = getTodayDateStr();
  const dayName = DAYS_OF_WEEK[new Date().getDay()];

  // Today's eaten log
  const todayLog = eatenLogs.find(log => log.date === todayDateStr) || {
    date: todayDateStr,
    meals: { breakfast: false, lunch: false, dinner: false, snacks: false }
  };

  // 1. BMI calculation
  const getBmiDetails = () => {
    if (!profile) return null;
    const heightMeters = profile.height / 100;
    const value = Number((profile.weight / (heightMeters * heightMeters)).toFixed(1));
    let status = 'Normal';
    let color = 'text-emerald-600 bg-emerald-50';

    if (value < 18.5) {
      status = 'Underweight';
      color = 'text-amber-600 bg-amber-50';
    } else if (value >= 25 && value < 30) {
      status = 'Overweight';
      color = 'text-amber-600 bg-amber-50';
    } else if (value >= 30) {
      status = 'Obese';
      color = 'text-rose-600 bg-rose-50';
    }

    return { value, status, color };
  };

  const bmi = getBmiDetails();

  // 2. TDEE and BMR estimates
  const getCalorieDetails = () => {
    if (!profile) return null;
    let bmr = 0;
    if (profile.gender === 'male') {
      bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age + 5;
    } else if (profile.gender === 'female') {
      bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age - 161;
    } else {
      bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age - 78;
    }

    let multiplier = 1.2;
    switch (profile.activityLevel) {
      case 'sedentary': multiplier = 1.2; break;
      case 'light': multiplier = 1.375; break;
      case 'moderate': multiplier = 1.55; break;
      case 'active': multiplier = 1.725; break;
      case 'very_active': multiplier = 1.9; break;
    }

    const tdee = Math.round(bmr * multiplier);
    let target = tdee;
    if (profile.fitnessGoal === 'lose') {
      target = Math.max(1200, tdee - 500);
    } else if (profile.fitnessGoal === 'gain') {
      target = tdee + 500;
    }

    return { bmr: Math.round(bmr), tdee, target };
  };

  const calories = getCalorieDetails();

  // 3. Find today's meals in the plan
  const getTodayMeals = () => {
    if (!dietPlan) return null;
    const match = dietPlan.days.find(d => d.dayName.toLowerCase() === dayName.toLowerCase());
    return match ? match.meals : dietPlan.days[0].meals; // fallback
  };

  const todayMeals = getTodayMeals();

  // Calculate adherence percent
  const eatenMealsCount = Object.values(todayLog.meals).filter(Boolean).length;
  const adherencePercent = Math.round((eatenMealsCount / 4) * 100);

  // Latest weight log
  const latestWeight = weightHistory.length > 0 
    ? [...weightHistory].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
    : null;

  return (
    <div className="space-y-6 font-sans">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden">
        <div className="relative z-10 space-y-1">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-1.5">
            Your Nutrition Dashboard <Sparkles className="h-5 w-5 fill-current text-emerald-200" />
          </h2>
          <p className="text-xs sm:text-sm text-emerald-50 max-w-xl">
            {profile 
              ? `You are on track for your ${profile.fitnessGoal === 'lose' ? 'Weight Loss' : profile.fitnessGoal === 'gain' ? 'Weight Gain' : 'Maintenance'} goal. Track today's meal schedule below.`
              : "Let's begin! Create your health metrics profile to calculate calories and generate your AI-powered 7-day meal schedule."
            }
          </p>
        </div>
        {!profile ? (
          <button
            onClick={() => onNavigate('profile')}
            className="px-5 py-2.5 bg-white text-emerald-700 text-xs font-bold rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer relative z-10 shrink-0"
          >
            Configure Health Profile
          </button>
        ) : (
          <div className="px-4 py-2 bg-white/10 rounded-xl border border-white/10 text-xs font-semibold backdrop-blur-sm self-stretch md:self-auto text-center shrink-0">
             Today: {dayName}
          </div>
        )}
      </div>

      {!profile ? (
        <div className="bg-white rounded-2xl border border-dashed border-gray-200 p-12 text-center max-w-lg mx-auto">
          <Activity className="h-12 w-12 text-emerald-400 mx-auto animate-pulse" />
          <h3 className="mt-4 text-base font-bold text-gray-900">Setup Profile to Access Dashboard</h3>
          <p className="mt-2 text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
            Enter your age, gender, height, weight, activity level, and goals. Our server will automatically evaluate your BMI, BMR, and TDEE to construct your diet.
          </p>
          <button
            onClick={() => onNavigate('profile')}
            className="mt-5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-xs font-bold text-white rounded-xl shadow-sm transition-all cursor-pointer"
          >
            Set Up Profile Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: BMI */}
          {bmi && (
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Estimated BMI Status</span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl font-black font-mono text-gray-950">{bmi.value}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${bmi.color}`}>
                    {bmi.status}
                  </span>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-50 text-[11px] text-gray-400">
                Healthy BMI range is between <span className="font-semibold text-gray-600">18.5 – 24.9</span>.
              </div>
            </div>
          )}

          {/* Card 2: Calorie Target */}
          {calories && (
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Target Daily Calories</span>
                <div className="flex items-baseline gap-1 mt-2">
                  <span className="text-3xl font-black font-mono text-emerald-600">{calories.target}</span>
                  <span className="text-xs font-bold text-gray-400">kcal / day</span>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-50 text-[11px] text-gray-500 flex justify-between">
                <span>BMR: <span className="font-mono font-bold text-gray-700">{calories.bmr}</span></span>
                <span>TDEE: <span className="font-mono font-bold text-gray-700">{calories.tdee}</span></span>
              </div>
            </div>
          )}

          {/* Card 3: Weight Progress */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Current Logged Weight</span>
              <div className="flex items-baseline gap-1.5 mt-2">
                <span className="text-3xl font-black font-mono text-gray-950">
                  {latestWeight ? latestWeight.weight : profile.weight}
                </span>
                <span className="text-xs font-bold text-gray-400">kg</span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-gray-50 flex justify-between items-center">
              <span className="text-[11px] text-gray-400">
                {weightHistory.length} logs entered
              </span>
              <button
                onClick={() => onNavigate('progress')}
                className="text-[11px] font-bold text-emerald-600 hover:text-emerald-500 flex items-center gap-0.5 cursor-pointer"
              >
                Log weight <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Today's Meals Timeline & Adherence (Left Col 2/3) */}
          <div className="md:col-span-2 space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-gray-900">Today's Meal Schedule ({dayName})</h3>
                  <p className="text-[11px] text-gray-400 mt-0.5">Toggle checkboxes to check off your meals as eaten.</p>
                </div>
                <button
                  onClick={() => onNavigate('diet')}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-500 flex items-center gap-0.5 cursor-pointer"
                >
                  Full 7-Day Plan <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>

              {!dietPlan ? (
                <div className="p-8 text-center text-xs text-gray-400 bg-gray-50/50 rounded-xl border border-dashed border-gray-100">
                  No diet plan generated yet. Go to full plan to trigger AI generation.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {[
                    { key: 'breakfast' as const, label: 'Breakfast', time: '08:00 AM' },
                    { key: 'lunch' as const, label: 'Lunch', time: '01:00 PM' },
                    { key: 'dinner' as const, label: 'Dinner', time: '07:30 PM' },
                    { key: 'snacks' as const, label: 'Snacks', time: '04:00 PM' }
                  ].map((item) => {
                    if (!todayMeals || !todayMeals[item.key]) return null;
                    const meal = todayMeals[item.key];
                    const eaten = todayLog.meals[item.key];

                    return (
                      <div
                        key={item.key}
                        className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                          eaten 
                            ? 'bg-emerald-50/50 border-emerald-200 text-emerald-900' 
                            : 'bg-white border-gray-100 text-gray-800 hover:bg-gray-50/40'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <button
                            onClick={() => onToggleMeal(todayDateStr, item.key)}
                            className="h-6 w-6 rounded-md border flex items-center justify-center shrink-0 transition-all cursor-pointer bg-white"
                          >
                            {eaten && <div className="h-3 w-3 rounded-sm bg-emerald-500" />}
                          </button>
                          <div className="min-w-0">
                            <span className="text-[9px] font-bold uppercase tracking-wider text-gray-400 block">{item.label} • {item.time}</span>
                            <span className={`text-xs font-bold block truncate mt-0.5 ${eaten ? 'line-through text-gray-400' : ''}`}>
                              {meal.mealName}
                            </span>
                          </div>
                        </div>

                        <span className="text-[11px] font-mono font-bold text-gray-500 shrink-0">{meal.calories} kcal</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Today's Stats & Energy Balance (Right Col 1/3) */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm h-full flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-sm font-bold text-gray-900">Today's Adherence</h3>
                <p className="text-[11px] text-gray-400 mt-0.5">Your meal completion rate for today's plan.</p>
              </div>

              {dietPlan ? (
                <div className="flex-1 flex flex-col items-center justify-center py-4 space-y-4">
                  {/* Circular visual progress meter */}
                  <div className="relative h-28 w-28 flex items-center justify-center">
                    <svg className="absolute inset-0 transform -rotate-90" viewBox="0 0 100 100">
                      {/* Background circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#f1f5f9"
                        strokeWidth="8"
                        fill="transparent"
                      />
                      {/* Active progress */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#10b981"
                        strokeWidth="8"
                        strokeDasharray={251.2}
                        strokeDashoffset={251.2 - (251.2 * adherencePercent) / 100}
                        strokeLinecap="round"
                        fill="transparent"
                        className="transition-all duration-500"
                      />
                    </svg>
                    <div className="text-center">
                      <span className="block text-2xl font-black font-mono text-gray-950">{adherencePercent}%</span>
                      <span className="block text-[9px] text-gray-400 uppercase font-bold">Eaten</span>
                    </div>
                  </div>

                  <p className="text-xs text-gray-500 font-medium text-center">
                    {eatenMealsCount} of 4 meals marked as eaten today.
                  </p>
                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center text-xs text-gray-400 text-center py-10">
                  Configure profile metrics to populate adherence stats.
                </div>
              )}

              <div className="pt-3 border-t border-gray-50">
                <button
                  onClick={() => onNavigate('diet')}
                  className="w-full text-center py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Track / Mark Meals
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
