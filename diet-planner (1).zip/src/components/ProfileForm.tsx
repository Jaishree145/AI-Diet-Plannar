import React, { useState } from 'react';
import { motion } from 'motion/react';
import { UserProfile } from '../types';
import { ChevronRight, Info, AlertTriangle, Dumbbell, Target, Carrot, Activity } from 'lucide-react';

interface ProfileFormProps {
  initialProfile?: UserProfile;
  onSubmit: (profile: UserProfile) => void;
  isLoading: boolean;
}

const COMMON_ALLERGENS = [
  'Gluten',
  'Peanuts',
  'Tree Nuts',
  'Dairy',
  'Eggs',
  'Soy',
  'Fish',
  'Shellfish'
];

export default function ProfileForm({ initialProfile, onSubmit, isLoading }: ProfileFormProps) {
  const [age, setAge] = useState(initialProfile?.age || 28);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>(initialProfile?.gender || 'male');
  const [height, setHeight] = useState(initialProfile?.height || 175);
  const [weight, setWeight] = useState(initialProfile?.weight || 70);
  const [activityLevel, setActivityLevel] = useState<UserProfile['activityLevel']>(
    initialProfile?.activityLevel || 'moderate'
  );
  const [fitnessGoal, setFitnessGoal] = useState<UserProfile['fitnessGoal']>(
    initialProfile?.fitnessGoal || 'maintain'
  );
  const [dietaryPreference, setDietaryPreference] = useState<UserProfile['dietaryPreference']>(
    initialProfile?.dietaryPreference || 'non_vegetarian'
  );
  
  // Allergies state
  const [selectedAllergens, setSelectedAllergens] = useState<string[]>(() => {
    if (!initialProfile?.allergies) return [];
    return initialProfile.allergies.filter(a => COMMON_ALLERGENS.includes(a));
  });
  const [customAllergy, setCustomAllergy] = useState('');
  const [customAllergens, setCustomAllergens] = useState<string[]>(() => {
    if (!initialProfile?.allergies) return [];
    return initialProfile.allergies.filter(a => !COMMON_ALLERGENS.includes(a));
  });

  const handleAllergenToggle = (allergen: string) => {
    if (selectedAllergens.includes(allergen)) {
      setSelectedAllergens(selectedAllergens.filter(a => a !== allergen));
    } else {
      setSelectedAllergens([...selectedAllergens, allergen]);
    }
  };

  const addCustomAllergy = (e: React.FormEvent) => {
    e.preventDefault();
    if (customAllergy.trim() && !customAllergens.includes(customAllergy.trim())) {
      setCustomAllergens([...customAllergens, customAllergy.trim()]);
      setCustomAllergy('');
    }
  };

  const removeCustomAllergy = (allergy: string) => {
    setCustomAllergens(customAllergens.filter(a => a !== allergy));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAllergies = [...selectedAllergens, ...customAllergens];
    
    onSubmit({
      age: Number(age),
      gender,
      height: Number(height),
      weight: Number(weight),
      activityLevel,
      fitnessGoal,
      dietaryPreference,
      allergies: finalAllergies
    });
  };

  // Live Calculations for user visual feedback
  const heightMeters = height / 100;
  const bmi = heightMeters > 0 ? Number((weight / (heightMeters * heightMeters)).toFixed(1)) : 0;
  
  let bmiCategory = 'Normal';
  let bmiColor = 'text-emerald-600 bg-emerald-50 border-emerald-100';
  if (bmi < 18.5) {
    bmiCategory = 'Underweight';
    bmiColor = 'text-amber-600 bg-amber-50 border-amber-100';
  } else if (bmi >= 25 && bmi < 30) {
    bmiCategory = 'Overweight';
    bmiColor = 'text-amber-600 bg-amber-50 border-amber-100';
  } else if (bmi >= 30) {
    bmiCategory = 'Obese';
    bmiColor = 'text-rose-600 bg-rose-50 border-rose-100';
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
      >
        {/* Header */}
        <div className="px-6 py-8 border-b border-gray-50 bg-gradient-to-r from-emerald-50/50 to-teal-50/30">
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Configure Your Health Profile</h2>
          <p className="mt-1 text-sm text-gray-500">
            Tell us about yourself. Our AI uses these exact parameters to compute calories, target macros, and generate a customized diet.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-8">
          
          {/* Section 1: Physical Metrics */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4 pb-2 border-b border-gray-50">
              <Activity className="h-5 w-5 text-emerald-500" />
              Physical Metrics
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              {/* Age */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="profile-age">Age (years)</label>
                <input
                  id="profile-age"
                  type="number"
                  min="10"
                  max="120"
                  required
                  value={age}
                  onChange={(e) => setAge(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900 transition-all text-sm font-mono"
                />
              </div>

              {/* Gender */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="profile-gender">Gender</label>
                <select
                  id="profile-gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900 transition-all text-sm"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Height */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="profile-height">Height (cm)</label>
                <input
                  id="profile-height"
                  type="number"
                  min="50"
                  max="250"
                  required
                  value={height}
                  onChange={(e) => setHeight(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900 transition-all text-sm font-mono"
                />
              </div>

              {/* Weight */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="profile-weight">Weight (kg)</label>
                <input
                  id="profile-weight"
                  type="number"
                  min="20"
                  max="300"
                  required
                  value={weight}
                  onChange={(e) => setWeight(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900 transition-all text-sm font-mono"
                />
              </div>
            </div>

            {/* Instant BMI Card */}
            <div className="mt-4 p-4 rounded-xl border border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-2.5">
                <Info className="h-5 w-5 text-gray-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-gray-900">Estimated Body Mass Index (BMI)</h4>
                  <p className="text-xs text-gray-500 mt-0.5">Calculated in real-time from your height and weight metrics.</p>
                </div>
              </div>
              <div className="flex items-center gap-3 self-end sm:self-auto">
                <div className="text-right">
                  <span className="block text-xl font-bold font-mono text-gray-900">{bmi > 0 ? bmi : '--'}</span>
                </div>
                {bmi > 0 && (
                  <span className={`px-2.5 py-1 text-xs font-semibold rounded-lg border ${bmiColor}`}>
                    {bmiCategory}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Activity & Fitness Goals */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4 pb-2 border-b border-gray-50">
              <Dumbbell className="h-5 w-5 text-emerald-500" />
              Activity & Goals
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Activity Level */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="profile-activity">Activity Level</label>
                <select
                  id="profile-activity"
                  value={activityLevel}
                  onChange={(e) => setActivityLevel(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900 transition-all text-sm"
                >
                  <option value="sedentary">Sedentary (Little/no exercise, desk job)</option>
                  <option value="light">Lightly Active (Light exercise 1-3 days/week)</option>
                  <option value="moderate">Moderately Active (Moderate workout 3-5 days/week)</option>
                  <option value="active">Active (Hard exercise 6-7 days/week)</option>
                  <option value="very_active">Extremely Active (Very hard exercise, physical job)</option>
                </select>
                <p className="mt-1.5 text-xs text-gray-400">
                  Used to estimate your Total Daily Energy Expenditure (TDEE).
                </p>
              </div>

              {/* Fitness Goal */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2" htmlFor="profile-fitness-goal-field">Fitness Goal</label>
                <div className="grid grid-cols-3 gap-2" id="profile-fitness-goal-field">
                  {(['lose', 'maintain', 'gain'] as const).map((goal) => (
                    <button
                      key={goal}
                      type="button"
                      onClick={() => setFitnessGoal(goal)}
                      className={`py-2 px-3 text-xs font-semibold rounded-xl border text-center transition-all cursor-pointer ${
                        fitnessGoal === goal
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm ring-1 ring-emerald-300'
                          : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <span className="capitalize">{goal === 'lose' ? 'Lose Weight' : goal === 'gain' ? 'Gain Weight' : 'Maintain'}</span>
                    </button>
                  ))}
                </div>
                <p className="mt-1.5 text-xs text-gray-400">
                  Adds or subtracts a deficit/surplus calories from your estimated TDEE.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Dietary Preferences */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4 pb-2 border-b border-gray-50">
              <Carrot className="h-5 w-5 text-emerald-500" />
              Dietary Preferences
            </h3>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2" htmlFor="profile-dietary-preference">Dietary Option</label>
              <div className="grid grid-cols-3 gap-3" id="profile-dietary-preference">
                {[
                  { value: 'non_vegetarian', label: 'Non-Vegetarian', desc: 'Eat meats, seafood & eggs' },
                  { value: 'vegetarian', label: 'Vegetarian', desc: 'No meat or seafood, eggs/dairy ok' },
                  { value: 'vegan', label: 'Vegan', desc: 'Strictly plant-based food only' }
                ].map((pref) => (
                  <button
                    key={pref.value}
                    type="button"
                    onClick={() => setDietaryPreference(pref.value as any)}
                    className={`p-3 text-left rounded-xl border transition-all flex flex-col justify-between cursor-pointer h-20 ${
                      dietaryPreference === pref.value
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800 shadow-sm ring-1 ring-emerald-300'
                        : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <span className="text-xs font-bold block">{pref.label}</span>
                    <span className="text-[10px] text-gray-400 block mt-1 leading-normal">{pref.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 4: Allergies & Restrictions */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4 pb-2 border-b border-gray-50">
              <AlertTriangle className="h-5 w-5 text-emerald-500" />
              Allergies & Exclusions
            </h3>

            <div className="space-y-4">
              <div>
                <span className="block text-sm font-medium text-gray-700 mb-2">Common Allergens (Tap to select)</span>
                <div className="flex flex-wrap gap-2">
                  {COMMON_ALLERGENS.map((allergen) => {
                    const selected = selectedAllergens.includes(allergen);
                    return (
                      <button
                        key={allergen}
                        type="button"
                        onClick={() => handleAllergenToggle(allergen)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-full border transition-all cursor-pointer ${
                          selected
                            ? 'bg-red-50 text-red-700 border-red-200 font-semibold shadow-sm'
                            : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        {allergen}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Allergies */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="custom-allergy-input">Custom Allergen / Food to Avoid</label>
                <div className="flex gap-2">
                  <input
                    id="custom-allergy-input"
                    type="text"
                    value={customAllergy}
                    onChange={(e) => setCustomAllergy(e.target.value)}
                    placeholder="e.g. Cilantro, Mushroom, Honey..."
                    className="flex-1 px-3 py-1.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                  />
                  <button
                    type="button"
                    onClick={addCustomAllergy}
                    className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-all cursor-pointer"
                  >
                    Add
                  </button>
                </div>

                {/* Custom Allergen Tags */}
                {customAllergens.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {customAllergens.map((allergy) => (
                      <span
                        key={allergy}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-full bg-red-50 text-red-700 border border-red-100"
                      >
                        {allergy}
                        <button
                          type="button"
                          onClick={() => removeCustomAllergy(allergy)}
                          className="font-bold hover:text-red-900 focus:outline-none text-[10px]"
                        >
                          ✕
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-gray-50 flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer w-full sm:w-auto"
            >
              {isLoading ? (
                <>
                  <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating Plan with Gemini...
                </>
              ) : (
                <>
                  Generate 7-Day Diet Plan
                  <ChevronRight className="h-4 w-4" />
                </>
              )}
            </button>
          </div>

        </form>
      </motion.div>
    </div>
  );
}
