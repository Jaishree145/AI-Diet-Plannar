import React, { useState } from 'react';
import { motion } from 'motion/react';
import { WeightLog } from '../types';
import { Scale, Calendar, Plus, Trash2, TrendingDown, TrendingUp, Minus } from 'lucide-react';

interface ProgressTrackerProps {
  weightHistory: WeightLog[];
  onAddLog: (weight: number, date: string) => void;
  onDeleteLog: (id: string) => void;
}

export default function ProgressTracker({ weightHistory, onAddLog, onDeleteLog }: ProgressTrackerProps) {
  const [weight, setWeight] = useState('');
  const [date, setDate] = useState(() => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });
  const [hoveredPoint, setHoveredPoint] = useState<{ idx: number; x: number; y: number; log: WeightLog } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericWeight = parseFloat(weight);
    if (!numericWeight || isNaN(numericWeight) || numericWeight <= 0) return;
    if (!date) return;

    onAddLog(numericWeight, date);
    setWeight('');
  };

  // Sort history chronologically for the chart
  const sortedHistory = [...weightHistory].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Statistics calculation
  const getStats = () => {
    if (sortedHistory.length === 0) return { current: '--', diff: 0, trend: 'stable' };
    
    const current = sortedHistory[sortedHistory.length - 1].weight;
    if (sortedHistory.length === 1) return { current, diff: 0, trend: 'stable' };

    const first = sortedHistory[0].weight;
    const diff = Number((current - first).toFixed(1));
    const trend = diff < 0 ? 'down' : diff > 0 ? 'up' : 'stable';

    return { current, diff, trend };
  };

  const stats = getStats();

  // SVG Chart Dimensions & Computations
  const width = 600;
  const height = 240;
  const paddingLeft = 50;
  const paddingRight = 30;
  const paddingTop = 30;
  const paddingBottom = 45;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  // Compute scale factors
  let points: { x: number; y: number; log: WeightLog }[] = [];
  let yGridLines: number[] = [];

  if (sortedHistory.length >= 2) {
    const weights = sortedHistory.map(h => h.weight);
    const minWeight = Math.min(...weights);
    const maxWeight = Math.max(...weights);
    
    // Create a 4kg buffer on top and bottom so the line fits beautifully
    const yMin = Math.max(0, minWeight - 4);
    const yMax = maxWeight + 4;
    const yRange = yMax - yMin;

    const times = sortedHistory.map(h => new Date(h.date).getTime());
    const minTime = Math.min(...times);
    const maxTime = Math.max(...times);
    const timeRange = maxTime - minTime || 1; // avoid divide by 0 if dates are equal

    // Map historical entries to SVG points
    points = sortedHistory.map((log) => {
      const timeVal = new Date(log.date).getTime();
      const xRatio = (timeVal - minTime) / timeRange;
      const yRatio = (log.weight - yMin) / yRange;

      const x = paddingLeft + xRatio * chartWidth;
      const y = paddingTop + (1 - yRatio) * chartHeight; // invert Y since (0,0) is top-left

      return { x, y, log };
    });

    // Generate grid points
    const step = yRange / 4;
    for (let i = 0; i <= 4; i++) {
      const val = yMin + step * i;
      yGridLines.push(val);
    }
  }

  // Construct SVG Path String
  const linePathString = points.length > 0 
    ? points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') 
    : '';

  // Construct SVG Area Filled Path String
  const areaPathString = points.length > 0
    ? `${linePathString} L ${points[points.length - 1].x} ${height - paddingBottom} L ${points[0].x} ${height - paddingBottom} Z`
    : '';

  return (
    <div className="space-y-6 font-sans">
      
      {/* Weight Tracker Dashboard row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Statistics metrics */}
        <div className="md:col-span-1 space-y-4">
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-4">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Your Weight Progress</h3>
              <p className="text-xs text-gray-400 mt-1">Track your progress relative to your fitness goal.</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-gray-50/70 border border-gray-100">
                <span className="block text-[10px] uppercase font-bold text-gray-400">Current Weight</span>
                <span className="block text-xl font-extrabold font-mono text-gray-900 mt-1">
                  {stats.current} <span className="text-xs font-normal text-gray-500">kg</span>
                </span>
              </div>

              <div className="p-4 rounded-xl bg-gray-50/70 border border-gray-100 flex flex-col justify-between">
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400">Overall Change</span>
                  <span className={`block text-sm font-extrabold font-mono mt-1 ${
                    stats.trend === 'down' ? 'text-emerald-600' : stats.trend === 'up' ? 'text-amber-600' : 'text-gray-500'
                  }`}>
                    {stats.diff > 0 ? `+${stats.diff}` : stats.diff} kg
                  </span>
                </div>
                <div className="flex items-center gap-1.5 mt-2">
                  {stats.trend === 'down' && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100">
                      <TrendingDown className="h-3 w-3" /> Downward
                    </span>
                  )}
                  {stats.trend === 'up' && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100">
                      <TrendingUp className="h-3 w-3" /> Upward
                    </span>
                  )}
                  {stats.trend === 'stable' && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-700">
                      <Minus className="h-3 w-3" /> Stable
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Log Form */}
            <form onSubmit={handleSubmit} className="pt-4 border-t border-gray-50 space-y-4">
              <span className="block text-xs font-bold text-gray-500 uppercase tracking-wider">Log Weight Entry</span>
              
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-gray-500 mb-1" htmlFor="weight-log-input">Weight (kg)</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <Scale className="h-4 w-4" />
                    </div>
                    <input
                      id="weight-log-input"
                      type="number"
                      step="0.1"
                      required
                      placeholder="e.g. 70.5"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="block w-full pl-9 pr-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-gray-500 mb-1" htmlFor="weight-date-input">Log Date</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                      <Calendar className="h-4 w-4" />
                    </div>
                    <input
                      id="weight-date-input"
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="block w-full pl-9 pr-3 py-2 border border-gray-200 rounded-xl bg-gray-50/50 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all cursor-pointer"
                >
                  <Plus className="h-4 w-4" /> Save Log Entry
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Chart View */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm h-full flex flex-col justify-between space-y-4">
            <div>
              <h3 className="text-sm font-bold text-gray-900">Weight Trend Timeline</h3>
              <p className="text-xs text-gray-400 mt-1">Timeline visualizer for logs entered.</p>
            </div>

            {/* SVG Chart */}
            <div className="flex-1 min-h-[220px] flex items-center justify-center relative bg-gray-50/30 rounded-xl border border-gray-50 p-2">
              {sortedHistory.length < 2 ? (
                <div className="text-center p-6 space-y-2">
                  <Scale className="h-8 w-8 text-gray-300 mx-auto" />
                  <p className="text-xs font-medium text-gray-500 max-w-xs">
                    Please log at least <span className="font-semibold text-emerald-600">two weight entries</span> on different dates to generate your trend timeline chart.
                  </p>
                </div>
              ) : (
                <div className="w-full h-full relative">
                  <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full">
                    <defs>
                      <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#10b981" stopOpacity="0.01" />
                      </linearGradient>
                    </defs>

                    {/* Grid lines */}
                    {yGridLines.map((gridVal, i) => {
                      const yWeights = sortedHistory.map(h => h.weight);
                      const minW = Math.min(...yWeights);
                      const maxW = Math.max(...yWeights);
                      const yMin = Math.max(0, minW - 4);
                      const yMax = maxW + 4;
                      const yRange = yMax - yMin;

                      const yRatio = (gridVal - yMin) / yRange;
                      const y = paddingTop + (1 - yRatio) * chartHeight;

                      return (
                        <g key={i}>
                          <line
                            x1={paddingLeft}
                            y1={y}
                            x2={width - paddingRight}
                            y2={y}
                            stroke="#f1f5f9"
                            strokeWidth="1"
                          />
                          <text
                            x={paddingLeft - 10}
                            y={y + 4}
                            textAnchor="end"
                            fontSize="9"
                            fill="#94a3b8"
                            className="font-mono font-medium"
                          >
                            {gridVal.toFixed(1)}
                          </text>
                        </g>
                      );
                    })}

                    {/* Gradient Area under curve */}
                    <path d={areaPathString} fill="url(#areaGrad)" />

                    {/* Main Line path */}
                    <path
                      d={linePathString}
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                    />

                    {/* X-axis Helper Label (First & Last date) */}
                    <text
                      x={points[0].x}
                      y={height - paddingBottom + 20}
                      textAnchor="middle"
                      fontSize="9"
                      fill="#94a3b8"
                      className="font-medium"
                    >
                      {points[0].log.date}
                    </text>
                    {points.length > 1 && (
                      <text
                        x={points[points.length - 1].x}
                        y={height - paddingBottom + 20}
                        textAnchor="middle"
                        fontSize="9"
                        fill="#94a3b8"
                        className="font-medium"
                      >
                        {points[points.length - 1].log.date}
                      </text>
                    )}

                    {/* Interactive dots */}
                    {points.map((pt, i) => (
                      <circle
                        key={pt.log.id}
                        cx={pt.x}
                        cy={pt.y}
                        r="5"
                        fill="#ffffff"
                        stroke="#10b981"
                        strokeWidth="2"
                        className="transition-all duration-150 cursor-pointer hover:r-7"
                        onMouseEnter={() => setHoveredPoint({ idx: i, x: pt.x, y: pt.y, log: pt.log })}
                        onMouseLeave={() => setHoveredPoint(null)}
                      />
                    ))}
                  </svg>

                  {/* Chart Tooltip Overlay */}
                  {hoveredPoint && (
                    <div
                      className="absolute p-2 bg-gray-900 text-white rounded-lg text-[10px] pointer-events-none shadow-md border border-gray-800 flex flex-col gap-0.5 z-10"
                      style={{
                        left: `${(hoveredPoint.x / width) * 100}%`,
                        top: `${(hoveredPoint.y / height) * 100 - 18}%`,
                        transform: 'translate(-50%, -100%)'
                      }}
                    >
                      <span className="font-bold">{hoveredPoint.log.weight} kg</span>
                      <span className="text-gray-400 font-mono text-[9px]">{hoveredPoint.log.date}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>

      </div>

      {/* Weight Log History */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <div>
          <h3 className="text-sm font-bold text-gray-900">Historical Log Entries</h3>
          <p className="text-xs text-gray-400 mt-1">Review and manage your historical log records.</p>
        </div>

        <div className="mt-4 overflow-hidden border border-gray-50 rounded-xl">
          {sortedHistory.length === 0 ? (
            <p className="p-6 text-center text-xs text-gray-400">No logs entered yet. Enter metrics above to begin tracking weight over time.</p>
          ) : (
            <div className="max-h-[220px] overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-gray-50 text-gray-500 font-bold border-b border-gray-100 uppercase text-[9px] tracking-wider">
                    <th className="p-3">Log Date</th>
                    <th className="p-3">Logged Weight</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {sortedHistory.map((log) => (
                    <tr key={log.id} className="hover:bg-gray-50/50 transition-all text-gray-700">
                      <td className="p-3 font-mono">{log.date}</td>
                      <td className="p-3 font-bold font-mono">{log.weight} kg</td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onDeleteLog(log.id)}
                          className="p-1 text-gray-400 hover:text-red-500 rounded hover:bg-red-50/50 transition-all cursor-pointer inline-flex items-center"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
