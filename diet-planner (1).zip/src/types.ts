export interface UserProfile {
  age: number;
  gender: 'male' | 'female' | 'other';
  height: number; // in cm
  weight: number; // in kg
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  fitnessGoal: 'lose' | 'maintain' | 'gain';
  dietaryPreference: 'vegetarian' | 'non_vegetarian' | 'vegan';
  allergies: string[];
}

export interface Meal {
  mealName: string;
  calories: number;
  protein: number; // in grams
  carbs: number; // in grams
  fat: number; // in grams
  ingredients: string[];
}

export interface DailyMeals {
  breakfast: Meal;
  lunch: Meal;
  dinner: Meal;
  snacks: Meal;
}

export interface DayPlan {
  dayName: string; // e.g., "Monday"
  meals: DailyMeals;
}

export interface DietPlan {
  id: string;
  createdAt: string;
  days: DayPlan[];
}

export interface WeightLog {
  id: string;
  date: string; // YYYY-MM-DD
  weight: number; // in kg
}

export interface EatenLog {
  date: string; // YYYY-MM-DD
  meals: {
    breakfast: boolean;
    lunch: boolean;
    dinner: boolean;
    snacks: boolean;
  };
}

export interface UserAccount {
  username: string;
  profile?: UserProfile;
  dietPlan?: DietPlan;
  weightHistory: WeightLog[];
  eatenLogs: EatenLog[];
}
