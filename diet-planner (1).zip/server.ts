import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Calculate BMI & Calorie Target (TDEE/BMR) helper
function calculateTargets(profile: {
  age: number;
  gender: 'male' | 'female' | 'other';
  height: number;
  weight: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  fitnessGoal: 'lose' | 'maintain' | 'gain';
}) {
  const { age, gender, height, weight, activityLevel, fitnessGoal } = profile;

  // BMI = weight (kg) / (height (m))^2
  const heightInMeters = height / 100;
  const bmi = Number((weight / (heightInMeters * heightInMeters)).toFixed(1));

  // Mifflin-St Jeor BMR Equation
  let bmr = 0;
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else if (gender === 'female') {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  } else {
    // Average
    bmr = 10 * weight + 6.25 * height - 5 * age - 78;
  }

  // Activity Multiplier (TDEE)
  let multiplier = 1.2;
  switch (activityLevel) {
    case 'sedentary':
      multiplier = 1.2;
      break;
    case 'light':
      multiplier = 1.375;
      break;
    case 'moderate':
      multiplier = 1.55;
      break;
    case 'active':
      multiplier = 1.725;
      break;
    case 'very_active':
      multiplier = 1.9;
      break;
  }

  const tdee = Math.round(bmr * multiplier);

  // Adjust for Fitness Goal
  let targetCalories = tdee;
  if (fitnessGoal === 'lose') {
    targetCalories = Math.max(1200, tdee - 500); // minimum 1200 kcal for safety
  } else if (fitnessGoal === 'gain') {
    targetCalories = tdee + 500;
  }

  return { bmi, bmr: Math.round(bmr), tdee, targetCalories };
}

// 1. Health Status check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// 2. Calorie and BMI Calculator Endpoint
app.post("/api/calculate-targets", (req, res) => {
  try {
    const profile = req.body;
    if (!profile || !profile.age || !profile.gender || !profile.height || !profile.weight || !profile.activityLevel || !profile.fitnessGoal) {
       res.status(400).json({ error: "Missing required profile fields for calculation" });
       return;
    }
    const results = calculateTargets(profile);
    res.json(results);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Gemini-powered 7-day Diet Plan Generator Endpoint
app.post("/api/generate-diet", async (req, res) => {
  try {
    const { profile, targetCalories } = req.body;

    if (!profile) {
       res.status(400).json({ error: "Profile details are required" });
       return;
    }

    if (!process.env.GEMINI_API_KEY) {
       res.status(500).json({ error: "Gemini API Key is not configured on the server." });
       return;
    }

    const allergiesStr = profile.allergies && profile.allergies.length > 0 
      ? profile.allergies.join(", ") 
      : "no specific allergies";

    const prompt = `Generate a personalized, professional 7-day diet plan for a user with the following profile:
- Age: ${profile.age} years old
- Gender: ${profile.gender}
- Height: ${profile.height} cm
- Weight: ${profile.weight} kg
- Activity Level: ${profile.activityLevel} (sedentary, lightly active, moderately active, very active, extra active)
- Fitness Goal: ${profile.fitnessGoal} (weight loss/gain/maintenance)
- Dietary Preference: ${profile.dietaryPreference} (vegetarian, non-vegetarian, or vegan)
- Allergies or restrictions to strictly avoid: ${allergiesStr}

The calculated target daily calorie intake is exactly ${targetCalories || 2000} kcal.
Please ensure the sum of calories of breakfast, lunch, dinner, and snacks for each day is close to this daily target (within 100-150 kcal margin).
Meals must fit their dietary preference (e.g. absolutely no animal products for vegans, no meat/fish/poultry for vegetarians) and MUST NOT contain any of their specified allergens. 

Make the recipes diverse, practical, healthy, and appetizing. Define exact ingredients and portions.
Return the output strictly as a JSON object matching the requested schema. Do not include markdown wraps like \`\`\`json.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayName: { type: Type.STRING, description: "Day of the week (e.g. Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday)" },
                  meals: {
                    type: Type.OBJECT,
                    properties: {
                      breakfast: {
                        type: Type.OBJECT,
                        properties: {
                          mealName: { type: Type.STRING, description: "Name of the breakfast" },
                          calories: { type: Type.INTEGER, description: "Calorie estimate" },
                          protein: { type: Type.INTEGER, description: "Protein content in grams" },
                          carbs: { type: Type.INTEGER, description: "Carb content in grams" },
                          fat: { type: Type.INTEGER, description: "Fat content in grams" },
                          ingredients: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific ingredient measurements" }
                        },
                        required: ["mealName", "calories", "protein", "carbs", "fat", "ingredients"]
                      },
                      lunch: {
                        type: Type.OBJECT,
                        properties: {
                          mealName: { type: Type.STRING, description: "Name of the lunch" },
                          calories: { type: Type.INTEGER },
                          protein: { type: Type.INTEGER },
                          carbs: { type: Type.INTEGER },
                          fat: { type: Type.INTEGER },
                          ingredients: { type: Type.ARRAY, items: { type: Type.STRING } }
                        },
                        required: ["mealName", "calories", "protein", "carbs", "fat", "ingredients"]
                      },
                      dinner: {
                        type: Type.OBJECT,
                        properties: {
                          mealName: { type: Type.STRING, description: "Name of the dinner" },
                          calories: { type: Type.INTEGER },
                          protein: { type: Type.INTEGER },
                          carbs: { type: Type.INTEGER },
                          fat: { type: Type.INTEGER },
                          ingredients: { type: Type.ARRAY, items: { type: Type.STRING } }
                        },
                        required: ["mealName", "calories", "protein", "carbs", "fat", "ingredients"]
                      },
                      snacks: {
                        type: Type.OBJECT,
                        properties: {
                          mealName: { type: Type.STRING, description: "Name of the snacks" },
                          calories: { type: Type.INTEGER },
                          protein: { type: Type.INTEGER },
                          carbs: { type: Type.INTEGER },
                          fat: { type: Type.INTEGER },
                          ingredients: { type: Type.ARRAY, items: { type: Type.STRING } }
                        },
                        required: ["mealName", "calories", "protein", "carbs", "fat", "ingredients"]
                      }
                    },
                    required: ["breakfast", "lunch", "dinner", "snacks"]
                  }
                },
                required: ["dayName", "meals"]
              }
            }
          },
          required: ["days"]
        }
      }
    });

    const textResult = response.text;
    if (!textResult) {
      throw new Error("No response text received from Gemini.");
    }

    const dietData = JSON.parse(textResult.trim());
    res.json(dietData);

  } catch (err: any) {
    console.error("Error generating diet:", err);
    res.status(500).json({ error: err.message || "Failed to generate personalized diet plan." });
  }
});

// Vite Middleware & Static Files Setup
async function initializeApp() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

initializeApp().catch((err) => {
  console.error("Failed to start server:", err);
});
